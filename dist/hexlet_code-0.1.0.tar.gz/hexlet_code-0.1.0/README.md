### Hexlet tests and linter status:
[![Actions Status](https://github.com/nurgeld/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/nurgeld/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/30f74b2e65bb99f5f289/maintainability)](https://codeclimate.com/github/nurgeld/python-project-49/maintainability)